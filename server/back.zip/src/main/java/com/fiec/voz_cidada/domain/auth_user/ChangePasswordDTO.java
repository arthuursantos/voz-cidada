package com.fiec.voz_cidada.domain.auth_user;

public record ChangePasswordDTO(String currentPassword, String newPassword) {
}