package com.fiec.voz_cidada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VozCidadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VozCidadaApplication.class, args);
	}

}
