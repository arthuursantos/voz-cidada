package com.fiec.voz_cidada.domain.auth_user;

public record AuthenticationDTO(String login, String password) {
}
