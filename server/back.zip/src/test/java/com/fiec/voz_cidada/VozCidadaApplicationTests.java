package com.fiec.voz_cidada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VozCidadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
