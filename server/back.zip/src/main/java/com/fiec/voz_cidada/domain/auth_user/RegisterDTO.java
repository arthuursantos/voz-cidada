package com.fiec.voz_cidada.domain.auth_user;

public record RegisterDTO(String login, String password, UserRole role, AuthStatus authStatus) {
}
